function[] = df;

if ~strcmp(version,'7.0.0.19901 (R14)')
    set(gcf,'WindowStyle','docked')
end