go_artim03.m - 30 pixels long, 3 pixels in diameter, 500 fibers, 256pix images

go_artim04.m - 100 pixels long, 3 pixels in diameter, 500 fibers, 256pix images

go_artim07.m - 128x128x128, 3 pix in D, 1 pix smoothing

go_artim08.m - same as go_artim07, but no smoothing